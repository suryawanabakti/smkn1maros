<?php

namespace App\Filament\Resources\PelanggaranResource\Pages;

use App\Filament\Resources\PelanggaranResource;
use Filament\Actions;
use Filament\Resources\Pages\ViewRecord;

class ViewPelanggaran extends ViewRecord
{
    protected static string $resource = PelanggaranResource::class;
}
