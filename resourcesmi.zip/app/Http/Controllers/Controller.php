<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Http;

abstract class Controller {}
